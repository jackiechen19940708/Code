
class MyInteger {
    public int value = 0;

    public void addOne() {
        ++value;
    }
}

class PrintTime implements Runnable {
    MyInteger i;

    PrintTime(MyInteger i) {
        this.i = i;
    }

    public void run() {
        do {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
            }
            i.addOne();
            synchronized (i) {
                i.notifyAll();
            }
            System.out.print(i.value + " ");
        } while (true);
    }
}

class PrintMsg implements Runnable {
    MyInteger i;
    int interval;

    PrintMsg(MyInteger i, int interval) {
        this.i = i;
        this.interval = interval;
    }

    public void run() {
        do {
            synchronized (i) {
                try {
                    i.wait();
                } catch (InterruptedException e) {
                }
                if (i.value % (this.interval) == 0)
                    System.out.println("\n" + this.interval + " second message");
            }
        } while (true);
    }
}


public class Main2 {
    public static void main(String[] args) {
        MyInteger i = new MyInteger();

        new Thread(new PrintTime(i)).start();
        new Thread(new PrintMsg(i, 7)).start();
        new Thread(new PrintMsg(i, 15)).start();
    }
}