import java.lang.Object.*;
import java.lang.reflect.*;

public class Main3 {
    static void displayMethodInfo(Object obj) {
        try {
            StringBuilder funcString;
            Class<?> clz = obj.getClass();

            for (Method m : clz.getDeclaredMethods()) {
                funcString = new StringBuilder(m.getName() + " (");
                boolean first = true;
                if (m.getModifiers() == 0) {
                    funcString.append(clz.getSimpleName());
                    first = false;
                }
                for (Parameter parameter : m.getParameters()) {
                    if (first)
                        funcString.append(parameter.getParameterizedType().getTypeName());
                    else
                        funcString.append(", ").append(parameter.getParameterizedType().getTypeName());
                    first = false;
                }
                funcString.append(") -> ");
                funcString.append(m.getGenericReturnType());
                System.out.println(funcString);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        displayMethodInfo(new A());
    }
}

class A {
    void foo(int T1, int T2) {
    }

    int bar(float T1, int T2, String T3) {
        return 0;
    }

    static double doo() {
        return 0;
    }
}