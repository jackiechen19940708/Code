import java.lang.reflect.*;

public class Main4 {
    public static void main(String args[]) {
        try {
            Class<?> clz = Class.forName(args[0]);
            for (Method m : clz.getDeclaredMethods()) {
                if (m.getModifiers() != 0 &&
                        m.getName().startsWith("test") &&
                        m.getGenericReturnType().getTypeName().equals("boolean") &&
                        m.getParameterCount() == 0) {
                    if ((boolean) m.invoke(clz.newInstance()))
                        System.out.println("OK: " + m.getName() + " succeeded");
                    else
                        System.out.println("FAILED: " + m.getName() + " failed");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}

class MyClass {
    public static boolean test1(){return true;}
    public static boolean test2(){return false;}
    public static boolean testTAMU(boolean tamu){return tamu;}
    public boolean testCSE(){return false;}
    public static int testAggie(){return 2021;}
    public static boolean fakeTestAggie(){return false;}
}