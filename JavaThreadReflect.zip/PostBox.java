// This is the starter code. You are free to add methods and fields
// to this class.
/*
    Use lock because some threads want to modify the PostBoxes at the same time. need to lock its queue so that two threads do not modify them at the same time.
 */

import java.util.*;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class PostBox implements Runnable {
    private final int MAX_SIZE;
    private final Lock lock;

    class Message {
        String sender;
        String recipient;
        String msg;

        Message(String sender, String recipient, String msg) {
            this.sender = sender;
            this.recipient = recipient;
            this.msg = msg;
        }
    }

    private final LinkedList<Message> messages;
    private LinkedList<Message> myMessages;
    private String myId;
    private volatile boolean stop = false;

    public PostBox(String myId, int max_size) {
        messages = new LinkedList<Message>();
        this.myId = myId;
        this.myMessages = new LinkedList<Message>();
        this.MAX_SIZE = max_size;
        lock = new ReentrantLock();
        new Thread(this).start();
    }

    public PostBox(String myId, int max_size, PostBox p) {
        this.myId = myId;
        this.messages = p.messages;
        this.MAX_SIZE = max_size;
        this.myMessages = new LinkedList<Message>();
        lock = p.lock;
        new Thread(this).start();
    }

    public String getId() {
        return myId;
    }

    public void stop() {
        // make it so that this Runnable will stop when it next wakes
        stop = true;
    }

    public void send(String recipient, String msg) {
        // add a message to the shared message queue
        // shared queue need to be lock
        Message m = new Message(this.getId(), recipient, msg);
        lock.lock();
        try {
            messages.add(m);
        } finally {
            lock.unlock();
        }

    }

    public List<String> retrieve() {
        // return the contents of myMessages
        // and empty myMessages

        // shared queue need to be lock

        List<String> myMessagesReturn = null;
        lock.lock();

        try {
            myMessagesReturn = new LinkedList<>();
            for (Message m : myMessages) {
                myMessagesReturn.add("From " + m.sender
                        + " to " + m.recipient + ": " + m.msg);
            }
            myMessages.clear();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
        return myMessagesReturn;

    }

    public void run() {
        // loop while not stopped
        //   1. approximately once every second move all messages
        //      addressed to this post box from the shared message
        //      queue to the private myMessages queue
        //   2. also approximately once every second, if the private or
        //      shared message queue has more than MAX_SIZE messages,
        //      delete oldest messages so that the size of myMessages
        //      and messages is at most MAX_SIZE.


        while (!stop) {
            try {
                Thread.sleep(1000);
            } catch (Exception e) {
                e.printStackTrace();
            }

            lock.lock();

            try {
                for (int i = 0; i < messages.size(); i++) {
                    if (myId.equals(messages.get(i).recipient)) {
                        myMessages.add(messages.remove(i));
                        i--;
                    }

                    if (myMessages.size() > MAX_SIZE) {
                        do {
                            myMessages.removeFirst();
                        } while (myMessages.size() > MAX_SIZE);
                    }
                }
            } finally {
                lock.unlock();
            }
        }
    }
}

