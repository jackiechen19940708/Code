#!/usr/bin/python3
"""
CS-UY 2214
Jeff Epstein
Starter code for E20 assembler
asm.py
"""
import argparse
import re

three_register_instruction = ["add", "sub", "and", "or", "slt"]
two_register_instruction = {"slti": 1, "jeq": 6, "addi": 7, "movi": 7}
load_store_instruction = {"lw": 4, "sw": 5}


def load_store_instruction_convert(machine_code, instruction_line, op_code, labels):
    machine_code |= op_code << 13
    machine_code |= int(instruction_line[len(instruction_line) - 2:len(instruction_line) - 1]) << 10
    machine_code |= int(instruction_line[instruction_line.find("$") + 1:instruction_line.find("$") + 2]) << 7
    machine_code |= get_imm_value(instruction_line[instruction_line.find(",") + 1:instruction_line.find("(")], labels)
    return machine_code


def jump_convert(machine_code, instruction_line, op_code, labels):
    machine_code |= op_code << 13
    imm = get_imm_value(instruction_line.split(":")[-1].split()[1], labels)
    machine_code |= imm
    return machine_code


def get_imm_value(imm, labels):
    imm = imm.strip()
    if imm in labels:
        imm = labels[imm]
    else:
        if int(imm) < 0:
            imm = int(imm) + 2 ** 7
        else:
            imm = int(imm)
    return imm


def three_register_convert(machine_code, instruction_line, op_code):
    pattern = re.compile(r'\$\d{1}')
    machine_code |= int(pattern.findall(instruction_line)[0][1]) << 4
    machine_code |= int(pattern.findall(instruction_line)[1][1]) << 10
    machine_code |= int(pattern.findall(instruction_line)[2][1]) << 7
    machine_code |= op_code
    return machine_code


def two_register_convert(machine_code, instruction_line, op_code, instruction, labels, pc):
    pattern = re.compile(r'\$\d{1}')
    dst = int(pattern.findall(instruction_line)[0][1])
    if instruction == "movi":
        src = 0
    else:
        src = int(pattern.findall(instruction_line)[1][1])
    imm = get_imm_value(instruction_line.split(",")[-1], labels)
    if instruction == "jeq":
        imm -= (pc + 1)
        if int(imm) < 0:
            imm = int(imm) + 2 ** 7
        else:
            imm = int(imm)
        dst = int(pattern.findall(instruction_line)[1][1])
        src = int(pattern.findall(instruction_line)[0][1])
    machine_code |= op_code << 13
    machine_code |= src << 10
    machine_code |= dst << 7
    machine_code |= imm
    return machine_code


def print_machine_code(address, num):
    """
    print_line(address, num)
    Print a line of machine code in the required format.
    Parameters:
        address: int = RAM address of the instructions
        num: int = numeric value of machine instruction

    For example:
        ram[3] = 16'b0000000000101010;
    """
    instruction_in_binary = format(num, '016b')
    print("ram[%s] = 16'b%s;" % (address, instruction_in_binary))


def main():
    parser = argparse.ArgumentParser(description='Assemble E20 files into machine code')
    parser.add_argument('filename', help='The file containing assembly language, typically with .s suffix')
    cmdline = parser.parse_args()

    # current_address is the memory location that is currently
    # targeted by the assembler. We start at -1
    current_address = -1

    # we store a dict mapping labels to their values here
    labels = {}

    # our final output is a list of ints values representing
    # machine code instructions
    instructions = []

    # iterate through the line in the file, construct a list
    # of numeric values representing machine code
    lines = []
    with open(cmdline.filename) as file:
        for line in file:
            line = line.split("#", 1)[0].strip()
            line = line.split(" ")
            colons = []
            instruction_line = ""
            for i in range(len(line)):
                instruction_line += line[i]
            if (instruction_line != "" and ":" not in line[0]) or len(line) > 1:
                current_address += 1
            for ch in range(len(instruction_line)):
                if instruction_line[ch] == ":":
                    colons.append(ch)
            index = 0
            start = 0
            if len("".join(line)) > 0:
                lines.append(line)
            while index < len(colons):
                end = colons[index]
                if len(line) > 1:
                    labels[instruction_line[start:end].lower()] = current_address
                else:
                    labels[instruction_line[start:end].lower()] = current_address + 1
                start = end
                index += 1

    file.close()
    final_lines = []
    line_idx = 0
    while line_idx < len(lines):
        final_lines.append(lines[line_idx])
        line_idx += 1
        if line_idx >= len(lines):
            break
        if "".join(final_lines[-1]).endswith(":"):
            final_lines[-1] += lines[line_idx]
            line_idx += 1
    for i in range(len(final_lines)):
        final_lines[i] = " ".join(final_lines[i])
    current_address = -1
    for instruction_line in final_lines:
        current_address += 1
        code = 0
        instruction = instruction_line[instruction_line.find(":") + 1:instruction_line.find("$")].strip()
        if instruction in three_register_instruction:
            op_code = three_register_instruction.index(instruction)
            code = three_register_convert(code, instruction_line, op_code)
        elif instruction in two_register_instruction:
            op_code = two_register_instruction[instruction]
            if instruction != "jeq":
                pc = 0
            else:
                pc = current_address
            code = two_register_convert(code, instruction_line, op_code, instruction, labels, pc)
        elif instruction in load_store_instruction:
            op_code = load_store_instruction[instruction]
            code = load_store_instruction_convert(code, instruction_line, op_code, labels)
        elif instruction == "jr":
            code |= 1 << 3
            reg = int(instruction_line[len(instruction_line) - 1:])
            code |= reg << 10
        elif ".fill" in instruction_line:
            imm = get_imm_value(instruction_line.split("fill")[1], labels)
            code |= imm
        elif instruction_line[instruction_line.find(":") + 1:instruction_line.find(":") + 4].strip() == "jal":
            op_code = 3
            code = jump_convert(code, instruction_line, op_code, labels)
        elif instruction_line[instruction_line.find(":") + 1:instruction_line.find(":") + 2].strip() == "j":
            op_code = 2
            code = jump_convert(code, instruction_line, op_code, labels)
        elif instruction_line[instruction_line.find(":") + 1:].strip() == "halt":
            op_code = 2
            code |= op_code << 13
            code |= current_address
        instructions.append(code)
    for address, instruction in enumerate(instructions):
        print_machine_code(address, instruction)


if __name__ == "__main__":
    main()
