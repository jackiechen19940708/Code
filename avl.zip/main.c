
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <sys/time.h>
#include "avl.h"


int FindMinPath(struct AVLTree *tree, TYPE *path);
void printBreadthFirstTree(struct AVLTree *tree);


/* -----------------------
The main function
  param: argv = pointer to the name (and path) of a file that the program reads for adding elements to the AVL tree
*/
int main(int argc, char** argv) {

	FILE *file;
	int len, i;
	TYPE num; /* value to add to the tree from a file */
	struct timeval stop, start; /* variables for measuring execution time */
	int pathArray[100];  /* static array with values of nodes along the min-cost path of the AVL tree. The means that the depth of the AVL tree cannot be greater than 100 which is  sufficient for our purposes*/

	struct AVLTree *tree;
	
	tree = newAVLTree(); /*initialize and return an empty tree */
	
	file = fopen(argv[1], "r"); 	/* filename is passed in argv[1] */
	assert(file != 0);

	/* Read input file and add numbers to the AVL tree */
	while((fscanf(file, "%i", &num)) != EOF){
		addAVLTree(tree, num);		
	}
	/* Close the file  */
	fclose(file);

        printf("\nThe AVL tree has %d nodes.\n",tree->cnt);
	
	printf("\nPrinting the AVL tree breadth-first : \n");
	printBreadthFirstTree(tree);

	gettimeofday(&start, NULL);

	/* Find the minimum-cost path in the AVL tree*/
	len = FindMinPath(tree, pathArray);
	
	gettimeofday(&stop, NULL);

	/* Print out all numbers on the minimum-cost path */
	printf("\n\nThe minimum-cost path has %d nodes printed top-down from the root to the leaf: \n", len);
	for(i = 0; i < len; i++)
		printf("%d ", pathArray[i]);
	printf("\n");

	printf("\nYour execution time to find the mincost path is %f microseconds\n", (double) (stop.tv_usec - start.tv_usec));

        /* Free memory allocated to the tree */
	deleteAVLTree(tree); 
	
	return 0;
}

void preorder(struct AVLnode *node, TYPE *min_cost,TYPE tmpCost, TYPE *path, TYPE *cur_path, int *result_len, int *cur_len, TYPE v)
{
    int i;
    if(EQ(node,NULL)){
        if(LT(tmpCost,*min_cost)){
          *min_cost = tmpCost;
          for(i = 0; i < *cur_len; i++){
            path[i] = cur_path[i];
          }
          *result_len = *cur_len;
        }
        return;
    }
    cur_path[*cur_len] = node->val;
    (*cur_len)++;
    tmpCost = tmpCost + abs(v - node->val);
    preorder(node->left,  min_cost, tmpCost, path, cur_path, result_len, cur_len, node->val);
    preorder(node->right, min_cost, tmpCost, path, cur_path, result_len, cur_len, node->val);
    (*cur_len)--;

}
  
/* --------------------
Finds the minimum-cost path in an AVL tree
   Input arguments: 
        tree = pointer to the tree,
        path = pointer to array that stores values of nodes along the min-cost path, 
   Output: return the min-cost path length 

   pre: assume that
       path is already allocated sufficient memory space 
       tree exists and is not NULL
*/
int FindMinPath(struct AVLTree *tree, TYPE *path)
{
    int result_len = 0; 
    int cur_len = 0; 
    TYPE min_cost = (TYPE) 10000000; 
    TYPE cur_path[100];
    path[result_len++] = tree->root->val;
    if (tree->cnt > 1){
           preorder(tree->root, &min_cost, 0, path, cur_path, &result_len, &cur_len, tree->root->val);
    }
    return result_len;
}



/*
  queue data structure using linked list
*/
struct node
{
    struct AVLnode* data;
    struct node *next;
};
typedef struct node node;

struct queue
{
    int count;
    node *front;
    node *rear;
};
typedef struct queue queue;


void initialize(queue *q)
{
    q->count = 0;
    q->front = NULL;
    q->rear = NULL;
}

int isempty(queue *q)
{
    return (q->rear == NULL);
}

void enqueue(queue *q,struct AVLnode* value )
{
    node *tmp;
    tmp = malloc(sizeof(node));
    tmp->data = value;
    tmp->next = NULL;
    if(!isempty(q))
    {
        q->rear->next = tmp;
        q->rear = tmp;
    }
    else
    {
        q->front = tmp;
        q->rear = tmp;
    }
    q->count++;
}

struct AVLnode* dequeue(queue *q)
{
    node *tmp;
    struct AVLnode* n;
    n = q->front->data;
    tmp = q->front;
    q->front = q->front->next;
    q->count--;
    if (q->count == 0){
      q->rear = NULL;
    }
    free(tmp);
    return(n);
}

/* -----------------------
Printing the contents of an AVL tree in breadth-first fashion
  param: pointer to a tree
  pre: assume that tree was initialized well before calling this function
*/
void printBreadthFirstTree(struct AVLTree *tree)
{
   queue* q;
   if(EQ(tree, NULL) || EQ(tree->root, NULL)){
     return;
   }
   q = malloc(sizeof(queue));
   initialize(q);
   enqueue(q,tree->root);
   while(!isempty(q)){
     struct AVLnode* cur = dequeue(q);
     printf("%d ",cur->val);
     if(cur->left != NULL){
         enqueue(q,cur->left);
     }
     if(cur->right != NULL){
         enqueue(q,cur->right);
     }
   }
   free(q);
}




