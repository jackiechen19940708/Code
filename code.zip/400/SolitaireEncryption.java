import circularlinkedlist.CircularLinkedList;

import java.util.*;

public class SolitaireEncryption {
    static final int CARDA = 27;
    static final int CARDB = 28;

    public static char encryptChar(char letter, int key) {
        int value = letter - 'A';
        int encryptedValue = (value + key) % 26;
        char encryptedChar = (char) (encryptedValue + 'A');

        return encryptedChar;
    }


    public static char decryptChar(char letter, int key) {
        int value = letter - 'A';
        int decryptedValue = (value + (26 - key)) % 26;
        char decryptedChar = (char) (decryptedValue + 'A');

        return decryptedChar;
    }


    public static int getKey(CircularLinkedList<Integer> deck) { // calls the steps methods
        step1(deck);
        step2(deck);
        step3(deck);
        step4(deck);
        return step5(deck);
    }

    private static void step1(CircularLinkedList<Integer> deck) {
        for (int i = 0; i < deck.size; i++) {
            if (deck.getItem(i) == CARDA) {
                deck.remove(i);
                deck.add((i + 1) % deck.size, CARDA);
                return;
            }
        }
    }

    private static void step2(CircularLinkedList<Integer> deck) {
        for (int i = 0; i < deck.size; i++) {
            if (deck.getItem(i) == CARDB) {
                deck.remove(i);
                deck.add((i + 2) % deck.size, CARDB);
                return;
            }
        }
    }

    private static void step3(CircularLinkedList<Integer> deck) {
        CircularLinkedList<Integer> part1 = new CircularLinkedList<>();
        CircularLinkedList<Integer> part2 = new CircularLinkedList<>();
        CircularLinkedList<Integer> part3 = new CircularLinkedList<>();

        int cases = 0;
        for (int i = 0; i < CARDB; i++) {
            int toAssign = deck.remove(0);
            if (toAssign == CARDA || toAssign == CARDB) cases++;
            if (cases == 0) part1.add(toAssign);
            if (cases == 1 || toAssign == CARDA || toAssign == CARDB) part2.add(toAssign);
            if (cases == 2 && toAssign != CARDA && toAssign != CARDB) part3.add(toAssign);
        }

        int part3Size = part3.size;
        int part2Size = part2.size;
        int part1Size = part1.size;

        for (int i = 0; i < part3Size; i++) deck.add(part3.remove(0));
        for (int i = 0; i < part2Size; i++) deck.add(part2.remove(0));
        for (int i = 0; i < part1Size; i++) deck.add(part1.remove(0));
    }

    private static void step4(CircularLinkedList<Integer> deck) {
        int idx = deck.getItem(CARDA);
        CircularLinkedList<Integer> slice = new CircularLinkedList<>();
        for (int i = 0; i < idx; i++) slice.add(deck.remove(0));
        for (int i = 0; i < idx; i++) deck.add(CARDA - idx + i, slice.remove(0));
    }

    private static int step5(CircularLinkedList<Integer> deck) {
        return deck.getItem(deck.getItem(0));
    }

    public static CircularLinkedList<Integer> getCards() {
        CircularLinkedList<Integer> deck = new CircularLinkedList<>();
        int[] nums = new int[]{1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 3, 6, 9, 12, 15, 18, 21, 24, 27, 2, 5, 8, 11, 14, 17, 20, 23, 26};
        for (int value : nums) {
            deck.add(value);
        }
        return deck;
    }

    public static void main(String[] args) {
        CircularLinkedList<Integer> deck = getCards();
        String input = "Dr. McCann is insane!";
        input = input.toUpperCase();
        System.out.println(input);
        int charCount = 0;
        for (int i = 0; i < input.length(); i++) {
            if (Character.isLetter(input.charAt(i))) {
                charCount++;
            }
        }
        char[] newInput = new char[(int) Math.ceil(1.0 * charCount / 5) * 5];
        char[] encrypted = new char[(int) Math.ceil(1.0 * charCount / 5) * 5];
        Arrays.fill(newInput, 'X');
        int idx = 0;
        for (int i = 0; i < input.length(); i++) {
            if (Character.isLetter(input.charAt(i))) {
                newInput[idx++] = input.charAt(i);
            }
        }


        for (int i = 0; i < newInput.length; i++) {
            encrypted[i] = encryptChar(newInput[i], getKey(deck));
        }

        System.out.println(String.valueOf(encrypted));

        deck = getCards();

        char[] decrypted = new char[encrypted.length];
        for (int i = 0; i < encrypted.length; i++) {
            decrypted[i] = decryptChar(encrypted[i], getKey(deck));
        }
        System.out.println(String.valueOf(decrypted));
    }

}
