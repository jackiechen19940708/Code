import sys
import queue
import collections


class Node:
    def __init__(self, left_chicken, left_wolf, right_chicken, right_wolf, boat, father_node, action, depth):
        self.left_chicken = left_chicken
        self.right_chicken = right_chicken
        self.left_wolf = left_wolf
        self.right_wolf = right_wolf
        self.boat = boat  # boat is bool, 0 represent left, 1 represent right
        self.depth = depth
        self.state = (self.left_chicken, self.left_wolf, self.right_chicken, self.right_wolf, self.boat)
        self.father_node = father_node
        self.action = action
        self.key = int(right_chicken) + int(right_wolf) + int(boat)
        self.cost = int(depth) + (int(right_chicken) + int(right_wolf) - int(boat))

    def __lt__(self, other):
        return self.cost < other.cost


def read_file(name):
    with open(name) as fp:
        left = fp.readline().replace("\n", "").split(',')
        right = fp.readline().replace("\n", "").split(',')
        return Node(int(left[0]), int(left[1]), int(right[0]), int(right[1]), int(right[2]), None, None, 0)


def try_move(cur, chicken, wolf):
    # boat left
    if cur.boat == 0:
        if chicken <= cur.left_chicken and wolf <= cur.left_wolf:
            if (cur.left_chicken - chicken > 0) and (cur.left_chicken - chicken) >= (
                    cur.left_wolf - wolf) or cur.left_chicken - chicken == 0:
                if (cur.right_chicken + chicken > 0) and (cur.right_chicken + chicken) >= (
                        cur.right_wolf + wolf) or cur.right_chicken + chicken == 0:
                    return Node(cur.left_chicken - chicken, cur.left_wolf - wolf, cur.right_chicken + chicken,
                                cur.right_wolf + wolf, 1, cur,
                                (chicken, wolf, cur.boat), cur.depth + 1)


    # boat right
    else:
        if chicken <= cur.right_chicken and wolf <= cur.right_wolf:
            if (cur.right_chicken - chicken > 0) and (cur.right_chicken - chicken) >= (
                    cur.right_wolf - wolf) or cur.right_chicken - chicken == 0:
                if (cur.left_chicken + chicken > 0) and (cur.left_chicken + chicken) >= (
                        cur.left_wolf + wolf) or cur.left_chicken + chicken == 0:
                    return Node(cur.left_chicken + chicken, cur.left_wolf + wolf, cur.right_chicken - chicken,
                                cur.right_wolf - wolf, 0, cur,
                                (chicken, wolf, cur.boat), cur.depth + 1)


def expand(cur):
    next_states = collections.deque()
    cws = [(1, 0), (2, 0), (0, 1), (1, 1), (0, 2)]
    for cw in cws:
        node = try_move(cur, cw[0], cw[1])
        if node:
            next_states.append(node)
    return next_states


def get_path(cur):
    path = collections.deque()
    while cur.father_node:
        path.append(cur.action)
        cur = cur.father_node
    return path


def print_path(path, outfile):
    with open(outfile, "w") as fp:
        count = 0
        while path:
            out = path.pop()
            count += 1
            if out[2] == 1:
                line = "Step {}.Move {} chicken and {} wolf from right to left\n".format(count, out[0], out[1])
            else:
                line = "Step {}.Move {} chicken and {} wolf from left to right\n".format(count, out[0], out[1])
            fp.write(line)


def bfs(initial_state, goal_state):
    visit_queue = collections.deque([initial_state])
    visit_map = collections.defaultdict(list)
    visit_map[initial_state.key].append(initial_state.state)
    explored_queue = collections.deque()
    explored_map = collections.defaultdict(list)
    expand_node_count = 0
    while visit_queue:
        cur = visit_queue.popleft()
        visit_map[cur.key].remove(cur.state)
        if cur.state == goal_state.state:
            path = get_path(cur)
            print("# of nodes on the solution path = {}".format(cur.depth))
            print("# of nodes expanded = {}\n".format(expand_node_count))
            return path

        explored_queue.append(cur)
        explored_map[cur.key].append(cur.state)
        expand_node_count += 1
        for node in expand(cur):
            if node.state not in explored_map[node.key]:
                if node.state not in visit_map[node.key]:
                    visit_queue.append(node)
                    visit_map[node.key].append(node.state)

    print("no solution")


def dfs(initial_state, goal_state):
    visit_queue = collections.deque([initial_state])
    visit_map = collections.defaultdict(list)
    visit_map[initial_state.key].append(initial_state.state)

    explored_queue = collections.deque()
    explored_map = collections.defaultdict(list)
    expand_node_count = 0
    while visit_queue:
        cur = visit_queue.pop()
        visit_map[cur.key].remove(cur.state)
        if cur.state == goal_state.state:
            path = get_path(cur)
            print("# of nodes on the solution path = {}".format(cur.depth))
            print("# of nodes expanded = {}\n".format(expand_node_count))
            return path

        explored_queue.append(cur)
        explored_map[cur.key].append(cur.state)

        expand_node_count += 1
        for node in expand(cur):
            if node.state not in explored_map[node.key]:
                if node.state not in visit_map[node.key]:
                    visit_queue.append(node)
                    visit_map[node.key].append(node.state)

    print("no solution")


iddfs_expand_node_count = 0


def iddfs_helper(n, initial_state, goal_state):
    visit_queue = collections.deque([initial_state])
    visit_map = collections.defaultdict(list)
    visit_map[initial_state.key].append(initial_state.state)
    explored_queue = collections.deque()
    explored_map = collections.defaultdict(list)
    global iddfs_expand_node_count
    while visit_queue:
        cur = visit_queue.pop()
        visit_map[cur.key].remove(cur.state)

        if cur.state == goal_state.state:
            path = get_path(cur)
            print("# of nodes on the solution path = {}".format(cur.depth))
            print("# of nodes expanded = {}\n".format(iddfs_expand_node_count))
            return path

        explored_queue.append(cur)
        explored_map[cur.key].append(cur.state)
        iddfs_expand_node_count += 1

        if n > int(cur.depth):
            for node in expand(cur):
                if node.state not in explored_map[node.key]:
                    if node.state not in visit_map[node.key]:
                        visit_queue.append(node)
                        visit_map[node.key].append(node.state)


MAX_SIZE = int(1e7)


def iddfs(initial_state, goal_state):
    for n in range(MAX_SIZE):
        path = iddfs_helper(n, initial_state, goal_state)
        if path is None:
            continue
        else:
            return path
    print("no solution")


def astar(initial_state, goal_state):
    visit_queue = queue.PriorityQueue()
    visit_queue.put((initial_state.cost, initial_state))
    explored_queue = collections.deque()
    explored_map = collections.defaultdict(list)
    expand_node_count = 0
    while visit_queue:
        cur = visit_queue.get()
        cur = cur[1]

        if cur.state == goal_state.state:
            path = get_path(cur)
            print("# of nodes on the solution path = {}".format(cur.depth))
            print("# of nodes expanded = {}\n".format(expand_node_count))
            return path

        explored_queue.append(cur)
        explored_map[cur.key].append(cur.state)
        expand_node_count += 1
        for node in expand(cur):
            if node.state not in explored_map[node.key]:
                visit_queue.put((node.cost, node))

    print("no path")


def main():
    initial_state_file = sys.argv[1]
    goal_state_file = sys.argv[2]
    mode = sys.argv[3]
    output_file = sys.argv[4]
    print(initial_state_file, goal_state_file, mode, output_file)
    initial_state = read_file(initial_state_file)
    goal_state = read_file(goal_state_file)

    path = globals()[mode](initial_state, goal_state)
    if path is not None:
        print_path(path, output_file)


if __name__ == "__main__":
    main()
