# Name (ID#):
# Lab: Assignment 4 Text Analysis
PUNCTUATIONS = [".", "!", "?", ",", ";"]


def read_file(filename):
    """
    read file content
    :param filename: file name
    :return: the lines in file
    """
    with open(filename) as fp:
        lines = fp.readlines()
    return lines


def clear_paragraph(paragraph, punctuations):
    """
    remove punctuation marks
    :param paragraph: input to be removed
    :param punctuations: punctuations to be removed
    :return: the removed paragraph
    """
    for punctuation in punctuations:
        paragraph = paragraph.replace(punctuation, " ")

    return paragraph


def get_paragraphs(lines):
    """
    get paragraphs from lines and clear them
    :param lines: file lines
    :return: paragraphs
    """
    paragraphs = []
    for line in lines:
        # not empty
        if line.replace("\n", "") != "":
            paragraphs.append(line)
    return paragraphs


def get_paragraph_sentences_words(paragraph):
    """
    report each paragraph's number of sentences and words
    :param paragraph: one paragraph
    :return: # of sentences and words
    """
    # count .|?|! to count number of sentences
    num_of_sentences = 0
    for c in paragraph:
        if c == "." or c == "?" or c == "!":
            num_of_sentences += 1
    # just split to see number of words
    paragraph = clear_paragraph(paragraph, PUNCTUATIONS)
    num_of_words = len(paragraph.split())
    return num_of_sentences, num_of_words


def report_overall(paragraphs, fp):
    """
    report overall number of words and occurrences
    :param paragraphs:
    :return:
    """
    count = 0
    occurs = {}
    for paragraph in paragraphs:
        # clear the paragraph
        paragraph = clear_paragraph(paragraph, PUNCTUATIONS)
        for word in paragraph.split():
            # convert to lower
            word = word.lower()
            if word not in occurs:
                occurs[word] = 0
            occurs[word] += 1
            count += 1
    print("Total # of words: " + str(count), file=fp)
    # select the max occur
    max_occur = 1
    for k, v in occurs.items():
        if v > max_occur:
            max_occur = v
    # determine time or times
    if max_occur > 1:
        postfix = "times"
    else:
        postfix = "time"
    # print output
    for k, v in occurs.items():
        if v == max_occur:
            print("\"" + k + "\" occurs " + str(max_occur) + " " + postfix, file=fp)


def report(paragraphs, fp):
    """
    report the paragraphs
    :param paragraphs: paragraphs to be reported
    :return: None
    """
    # report number of paragraphs
    print("# of paragraphs: " + str(len(paragraphs)) + "\n", file=fp)
    # report each paragraph's number of sentences and words
    for idx, paragraph in enumerate(paragraphs):
        num_of_sentences, num_of_words = get_paragraph_sentences_words(paragraph)
        print("Paragraph " + str(idx + 1) + ":", file=fp)
        print("  # of sentences: " + str(num_of_sentences) + "", file=fp)
        print("  # of words: " + str(num_of_words) + "", file=fp)
        print("", file=fp)
    # report overall number of words and occurrences
    report_overall(paragraphs, fp)


def main():
    """
    The main procedure
    """
    # get input file name from user
    filename = input("Please input filename:")
    if not filename.endswith(".in"):
        filename += ".in"
    # read file
    lines = read_file(filename)
    # get paragraphs
    paragraphs = get_paragraphs(lines)
    # report paragraphs
    with open(filename[:-3] + ".out", "w") as fp:
        report(paragraphs, fp)


if __name__ == "__main__":
    main()
